from transformers import pipeline, set_seed

generator = pipeline('text-generation', model='gpt2')
prompt = "The future of artificial intelligence in healthcare is"
set_seed(42)
output = generator(prompt, max_length=100, num_return_sequences=1)
print("Generated Text:\n", output[0]['generated_text'])