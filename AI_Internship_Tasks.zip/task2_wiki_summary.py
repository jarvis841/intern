from transformers import pipeline

summarizer = pipeline("summarization", model="facebook/bart-large-cnn")

long_text = """
India, officially the Republic of India, is a country in South Asia. It is the seventh-largest country by area,
the most populous country as of 2023, and from 1947 to 2023 the most populous democracy in the world. 
Bounded by the Indian Ocean on the south, the Arabian Sea on the southwest, and the Bay of Bengal on the southeast...
"""

summary = summarizer(long_text, max_length=100, min_length=30, do_sample=False)[0]['summary_text']
print("Original:\n", long_text[:300], "...")
print("\nSummary:\n", summary)