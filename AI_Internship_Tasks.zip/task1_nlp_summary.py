import nltk
import spacy
from newspaper import Article
from sklearn.feature_extraction.text import TfidfVectorizer
from heapq import nlargest
import re

nltk.download('punkt')
nlp = spacy.load("en_core_web_sm")

url = 'https://www.bbc.com/news/world-us-canada-66287915'
article = Article(url)
article.download()
article.parse()
article.nlp()

def clean_text(text):
    text = re.sub(r'\s+', ' ', text)
    text = re.sub(r'\[[^]]*\]', '', text)
    return text.strip()

cleaned_text = clean_text(article.text)
doc = nlp(cleaned_text)
keywords = [chunk.text for chunk in doc.noun_chunks if len(chunk.text) > 1]
unique_keywords = list(set(keywords))

sentences = nltk.sent_tokenize(cleaned_text)
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(sentences)
scores = X.sum(axis=1).flatten().tolist()[0]
summary_sentences = nlargest(3, zip(scores, sentences))
summary = ' '.join([sent for _, sent in summary_sentences])

print("Cleaned Text Sample:", cleaned_text[:300], '...')
print("\nKey Phrases:", unique_keywords[:10])
print("\nSummary:\n", summary)