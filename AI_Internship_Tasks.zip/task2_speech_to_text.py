import speech_recognition as sr

recognizer = sr.Recognizer()
audio_path = "sample.wav"

with sr.AudioFile(audio_path) as source:
    audio = recognizer.record(source)
    try:
        text = recognizer.recognize_google(audio)
        print("Transcription:\n", text)
    except sr.UnknownValueError:
        print("Could not understand audio")