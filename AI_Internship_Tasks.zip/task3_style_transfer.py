import tensorflow as tf
import tensorflow_hub as hub
import matplotlib.pyplot as plt
import numpy as np
import PIL.Image
import requests
from io import BytesIO

def load_image(url, size=(256, 256)):
    response = requests.get(url)
    image = PIL.Image.open(BytesIO(response.content)).convert("RGB")
    image = image.resize(size)
    return np.array(image) / 255.0

def tensor_to_image(tensor):
    tensor = tensor * 255
    return PIL.Image.fromarray(np.uint8(tensor[0]))

content_url = "https://tensorflow.org/images/tf_logo.png"
style_url = "https://tensorflow.org/images/style.jpg"

content_image = load_image(content_url)
style_image = load_image(style_url)

hub_model = hub.load('https://tfhub.dev/google/magenta/arbitrary-image-stylization-v1-256/2')
stylized_image = hub_model(tf.constant(content_image[np.newaxis, ...], dtype=tf.float32),
                           tf.constant(style_image[np.newaxis, ...], dtype=tf.float32))[0]

plt.figure(figsize=(10, 4))
plt.subplot(1, 3, 1); plt.imshow(content_image); plt.title("Content")
plt.subplot(1, 3, 2); plt.imshow(style_image); plt.title("Style")
plt.subplot(1, 3, 3); plt.imshow(tensor_to_image(stylized_image)); plt.title("Stylized")
plt.show()